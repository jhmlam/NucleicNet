Test files for installation
